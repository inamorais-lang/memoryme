const WEBHOOK_URL = "https://hooks.zapier.com/hooks/catch/24893696/u9xjucf/"; 
// Substitui acima pelo teu webhook do Zapier/Make se mudares o Zap.

document.getElementById('year').textContent = new Date().getFullYear();

document.querySelectorAll('[data-plan]').forEach(btn => {
  btn.addEventListener('click', () => {
    const select = document.querySelector('select[name="tipo"]');
    if(!select) return;
    const plan = btn.getAttribute('data-plan');
    const map = { express: 'Express', premium:'Premium', tributo:'Homenagem' };
    select.value = map[plan] || 'Express';
  });
});

async function handleSubmit(e){
  e.preventDefault();
  const form = e.target;
  const data = Object.fromEntries(new FormData(form).entries());
  const payload = {
    fonte: "Site MemoryMe",
    data_iso: new Date().toISOString(),
    pedido: {
      nome: data.nome,
      email: data.email,
      tipo: data.tipo,
      link: data.link,
      mensagem: data.mensagem || ""
    }
  };
  const status = document.getElementById('form-status');
  status.textContent = "A enviar o teu pedido...";
  try{
    const res = await fetch(WEBHOOK_URL, {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(payload)
    });
    if(!res.ok) throw new Error("Falha no envio");
    status.textContent = "Pedido enviado com sucesso. Em breve entraremos em contacto por email. Obrigado!";
    form.reset();
  }catch(err){
    console.error(err);
    status.textContent = "Não foi possível enviar automaticamente. Tenta novamente ou envia-nos email para hello@memoryme.pt";
  }
  return false;
}
